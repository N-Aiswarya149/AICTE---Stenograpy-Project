stego py need cv2 lib

solution 

pip install cv2
